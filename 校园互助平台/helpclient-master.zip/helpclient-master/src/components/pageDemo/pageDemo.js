let that ;
let list = {
  data(){
    return {

    }
  },
  mounted(){
    that = this;
  },
  methods:{

  }
}
module.exports = list
