define({
  "title": "YZY api",
  "url": "https://api.github.com/v1",
  "name": "server",
  "version": "0.1.0",
  "description": "",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-12-20T03:57:58.544Z",
    "url": "http://apidocjs.com",
    "version": "0.17.7"
  }
});
