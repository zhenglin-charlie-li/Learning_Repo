import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class TestMongoDB {
    @Test
    public void testMongoDB() {
        MongoDatabase mongoDatabase;
        String connectionString = "mongodb+srv://zhenglinli:i7EHnzmdP9YWhvyi@cluster0.fc4iuts.mongodb.net/?retryWrites=true&w=majority";
        MongoClient mongoClient = MongoClients.create(connectionString);
        mongoDatabase = mongoClient.getDatabase("coding6");
        System.out.println("Connected to MongoDB!");

        MongoCollection<Document> coding6 = mongoDatabase.getCollection("coding6");
        System.out.println("Collection coding6 selected successfully");

        Document orderDoc = new Document("OrderID", 1).append("CustomerID", 2).append("TotalCost", 3).append("OrderDate", 4).append("TotalTax", 5);
        List<Document> lineDocs = new ArrayList<>();
        Document lineDoc = new Document("OrderID", 1).append("ProductID", 2).append("Quantity", 3).append("Cost", 4);
        lineDocs.add(lineDoc);
        orderDoc.append("OrderLines", lineDocs);
        coding6.insertOne(orderDoc);

        FindIterable<Document> orderID = coding6.find(orderDoc);
        System.out.println(Objects.requireNonNull(orderID.first()).toJson());
    }
}
