import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ShipmentInfoController implements ActionListener {
    private ShipmentInfoView shipmentInfoView;

    public ShipmentInfoController(ShipmentInfoView shipmentInfoView) {
        this.shipmentInfoView = shipmentInfoView;

        shipmentInfoView.getBtnLoad().addActionListener(this);
        shipmentInfoView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == shipmentInfoView.getBtnLoad())
            loadShipmentInfo();
        else if (e.getSource() == shipmentInfoView.getBtnSave())
            saveShipmentInfo();
    }

    private void saveShipmentInfo() {
        // add data validation
        String shipmentInfoAddress = shipmentInfoView.getTxtShipmentInfoAddress().getText().trim();
        if (!isValidShipmentInfoAddress(shipmentInfoAddress)) {
            JOptionPane.showMessageDialog(null, "Invalid shipmentInfo address! Please provide a valid shipmentInfo address!");
            return;
        }

        // Done all validations! Make an object for this shipmentInfo!

        ShipmentInfo shipmentInfo = new ShipmentInfo();
        shipmentInfo.setAddress(shipmentInfoAddress);
        shipmentInfo.setUserID(Application.getInstance().getCurrentUser().getUserID());

        // Store the shipmentInfo to the database

        Application.getInstance().getDataAdapter().saveShipmentInfo(shipmentInfo);
    }

    private void loadShipmentInfo() {
        int userID = Application.getInstance().getCurrentUser().getUserID();

        ShipmentInfo shipmentInfo = Application.getInstance().getDataAdapter().loadShipmentInfo(userID);

        if (shipmentInfo == null) {
            JOptionPane.showMessageDialog(null, "This shipmentInfo ID does not exist in the database!");
            return;
        }

        shipmentInfoView.getTxtShipmentInfoAddress().setText(shipmentInfo.getAddress());
    }


    // add data validation
    private boolean isValidShipmentInfoAddress(String shipmentInfoAddress) {
        return !shipmentInfoAddress.isBlank();
    }


    // add data validation
    private boolean isValidShipmentInfoName(String shipmentInfoName) {
        return shipmentInfoName.trim().length() > 0 && shipmentInfoName.trim().length() < Integer.MAX_VALUE;
    }
}


class ShipmentInfoView extends JFrame {
    private JTextField txtShipmentInfoAddress = new JTextField(30);

    private JButton btnLoad = new JButton("Load main.java.ShipmentInfo");
    private JButton btnSave = new JButton("Save main.java.ShipmentInfo");

    public ShipmentInfoView() {
        this.setTitle("Manage main.java.ShipmentInfo");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 200);

        JPanel panelButton = new JPanel();
        panelButton.add(btnLoad);
        panelButton.add(btnSave);
        this.getContentPane().add(panelButton);

        JPanel panelShipmentInfoName = new JPanel();
        panelShipmentInfoName.add(new JLabel("main.java.ShipmentInfo Address: "));
        panelShipmentInfoName.add(txtShipmentInfoAddress);
        this.getContentPane().add(panelShipmentInfoName);

    }

    public JButton getBtnLoad() {
        return btnLoad;
    }

    public JButton getBtnSave() {
        return btnSave;
    }

    public JTextField getTxtShipmentInfoAddress() {
        return txtShipmentInfoAddress;
    }
}
