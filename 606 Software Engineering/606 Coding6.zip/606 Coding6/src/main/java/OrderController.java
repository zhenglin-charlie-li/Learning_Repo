import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Time;
import java.util.Random;

public class OrderController implements ActionListener {
    private OrderView view;
    private Order order;

    public OrderController(OrderView view) {
        this.view = view;

        view.getBtnAdd().addActionListener(this);
        view.getBtnPay().addActionListener(this);

        order = new Order();
        order.setOrderID(Math.abs(new Random().nextInt()));
    }

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnAdd()) addProduct();
        else if (e.getSource() == view.getBtnPay()) makeOrder();
    }

    private void makeOrder() {
        order.setBuyerID(Application.getInstance().getCurrentUser().getUserID());
        order.setTotalTax(order.getTotalCost() * 0.08);
        order.setPaymentInfo(Application.getInstance().getDataAdapter().loadPaymentInfo(Application.getInstance().getCurrentUser().getUserID()));
        order.setShipmentInfo(Application.getInstance().getDataAdapter().loadShipmentInfo(Application.getInstance().getCurrentUser().getUserID()));
        order.setDateTime(new Time(System.currentTimeMillis()).toString());

        if (!isOrderValid()) {
            return;
        }

        try {
            // for each order line, update records in database accordingly
            for (OrderLine orderLine : order.getLines()) {
                Product product = Application.getInstance().getDataAdapter().loadProduct(orderLine.getProductID());
                product.setQuantity(product.getQuantity() - orderLine.getQuantity());
                Application.getInstance().getDataAdapter().saveProduct(product);
            }
            // save order
            Application.getInstance().getDataAdapter().saveOrder(order);
            JOptionPane.showMessageDialog(null, "Order placed successfully!");
            // generate receipt
            generateReceipt();
            JOptionPane.showMessageDialog(null, "A Receipt was generated!!");
            // clean up the view after the order is placed successfully
            CleanUpView();
            order = new Order();
            order.setOrderID(Math.abs(new Random().nextInt()));
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Exception encountered, order not placed!");
        }
    }

    private void generateReceipt() {
        Receipt receipt = new Receipt();
        receipt.setOrderID(order.getOrderID());
        receipt.setUserID(order.getBuyerID());

        StringBuilder content = new StringBuilder();
        content.append("Order ID: ").append(receipt.getOrderID()).append(System.lineSeparator());
        content.append("Buyer ID: ").append(receipt.getUserID()).append(System.lineSeparator());
        content.append("Buyer Name: ").append(Application.getInstance().getCurrentUser().getFullName()).append(System.lineSeparator());
        content.append(System.lineSeparator());

        content.append("Order Lines: ").append(System.lineSeparator());
        for (int i = 0; i < order.getLines().size(); i++) {
            int index = i + 1;
            OrderLine orderLine = order.getLines().get(i);
            content.append("Product ID: ").append(orderLine.getProductID()).append('\t');
            content.append("Quantity: ").append(orderLine.getQuantity()).append('\t');
            content.append("Cost: ").append(orderLine.getCost()).append('\t');
            content.append(System.lineSeparator());
        }

        content.append(System.lineSeparator());
        content.append("Total Cost: ").append(order.getTotalCost()).append(System.lineSeparator());
        content.append("Total Tax: ").append(order.getTotalTax()).append(System.lineSeparator());
        content.append("Date: ").append(order.getDateTime()).append(System.lineSeparator());

        receipt.setContent(content.toString());

        Application.getInstance().getDataAdapter().saveReceipt(receipt);
    }

    private void CleanUpView() {
        this.view.deleteAllRows();
        this.view.getLabTotal().setText("");
    }

    private boolean isOrderValid() {
        if (order.getPaymentInfo() == null) {
            JOptionPane.showMessageDialog(null, "Payment Info is Empty!");
            return false;
        }
        if (order.getShipmentInfo() == null) {
            JOptionPane.showMessageDialog(null, "Shipment Info is Empty!");
            return false;
        }
        if (order.getLines().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Order Lines Are Empty!");
            return false;
        }
        return true;
    }

    private void addProduct() {
        String id = JOptionPane.showInputDialog("Enter ProductID: ");

        // add data validation
        if (!isInteger(id)) {
            JOptionPane.showMessageDialog(null, "This ProductID is not valid!");
            return;
        }

        Product product = Application.getInstance().getDataAdapter().loadProduct(Integer.parseInt(id));
        if (product == null) {
            JOptionPane.showMessageDialog(null, "This product does not exist!");
            return;
        }

        double quantity = Double.parseDouble(JOptionPane.showInputDialog(null, "Enter quantity: "));

        // add data validation
        if (quantity < 0 || quantity > product.getQuantity()) {
            JOptionPane.showMessageDialog(null, "This quantity is not valid!");
            return;
        }

        OrderLine line = new OrderLine();
        line.setOrderID(this.order.getOrderID());
        line.setProductID(product.getProductID());
        line.setQuantity(quantity);
        line.setCost(quantity * product.getPrice());
        order.getLines().add(line);
        order.setTotalCost(order.getTotalCost() + line.getCost());


        Object[] row = new Object[5];
        row[0] = line.getProductID();
        row[1] = product.getName();
        row[2] = product.getPrice();
        row[3] = line.getQuantity();
        row[4] = line.getCost();

        this.view.addRow(row);
        this.view.getLabTotal().setText("Total: $" + order.getTotalCost());
        this.view.invalidate();
    }

    // add data validation
    public static boolean isInteger(String s) {
        try {
            Integer.parseInt(s);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }

}

class OrderView extends JFrame {

    private JButton btnAdd = new JButton("Add a new item");
    private JButton btnPay = new JButton("Finish and pay");

    private DefaultTableModel items = new DefaultTableModel(); // store information for the table!

    private JTable tblItems = new JTable(items);
    private JLabel labTotal = new JLabel("Total: ");

    public OrderView() {

        this.setTitle("Order View");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.Y_AXIS));
        this.setSize(400, 600);


        items.addColumn("Product ID");
        items.addColumn("Name");
        items.addColumn("Price");
        items.addColumn("Quantity");
        items.addColumn("Cost");

        JPanel panelOrder = new JPanel();
        panelOrder.setPreferredSize(new Dimension(400, 450));
        panelOrder.setLayout(new BoxLayout(panelOrder, BoxLayout.PAGE_AXIS));
        tblItems.setBounds(0, 0, 400, 350);
        panelOrder.add(tblItems.getTableHeader());
        panelOrder.add(tblItems);
        panelOrder.add(labTotal);
        tblItems.setFillsViewportHeight(true);
        this.getContentPane().add(panelOrder);

        JPanel panelButton = new JPanel();
        panelButton.setPreferredSize(new Dimension(400, 100));
        panelButton.add(btnAdd);
        panelButton.add(btnPay);
        this.getContentPane().add(panelButton);

    }

    public JButton getBtnAdd() {
        return btnAdd;
    }

    public JButton getBtnPay() {
        return btnPay;
    }

    public JLabel getLabTotal() {
        return labTotal;
    }

    public void addRow(Object[] row) {
        items.addRow(row);
    }

    public void deleteAllRows() {
        int size = items.getRowCount();
        for (int i = size - 1; i >= 0; i--) {
            items.removeRow(i);
        }
    }
}