import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

public class ReceiptController implements ActionListener {
    private ReceiptView receiptView;

    public ReceiptController(ReceiptView receiptView) {
        this.receiptView = receiptView;

        receiptView.getBtnLoad().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == receiptView.getBtnLoad())
            loadReceipt();
    }

    private void loadReceipt() {
        int userID = Application.getInstance().getCurrentUser().getUserID();

        List<Receipt> receipts = Application.getInstance().getDataAdapter().loadReceipt(userID);

        if (receipts == null) {
            JOptionPane.showMessageDialog(null, "This receipt does not exist in the database!");
            return;
        }

        StringBuilder content = new StringBuilder();
        for (Receipt receipt : receipts) {
            content.append(receipt.getContent()).append(System.lineSeparator()).append(System.lineSeparator()).append(System.lineSeparator());
        }
        receiptView.getTxtReceiptContent().setText(content.toString());
    }


    // add data validation
    private boolean isValidReceiptAddress(String receiptAddress) {
        return !receiptAddress.isBlank();
    }


    // add data validation
    private boolean isValidReceiptName(String receiptName) {
        return receiptName.trim().length() > 0 && receiptName.trim().length() < Integer.MAX_VALUE;
    }
}


class ReceiptView extends JFrame {
    private JTextPane txtReceiptContent = new JTextPane();

    private JButton btnLoad = new JButton("Load main.java.Receipt");

    public ReceiptView() {
        this.setTitle("Manage main.java.Receipt");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 200);

        JPanel panelButton = new JPanel();
        panelButton.add(btnLoad);
        this.getContentPane().add(panelButton);

        JPanel panelReceiptContent = new JPanel();
        panelReceiptContent.add(new JLabel("main.java.Receipt Content: "));
        panelReceiptContent.add(txtReceiptContent);
        this.getContentPane().add(panelReceiptContent);

    }

    public JButton getBtnLoad() {
        return btnLoad;
    }

    public JTextPane getTxtReceiptContent() {
        return txtReceiptContent;
    }
}
