import org.bson.Document;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.exceptions.JedisException;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;

public class DataAdapter {
    private final Jedis jedis; // Redis client
    private final MongoDatabase mongoDatabase; // MongoDB client

    public DataAdapter() {
        this.jedis = new Jedis("redis://default:io8UXrrMd3efnZSowvdAT9pBroj3jpAY@redis-10414.c282.east-us-mz.azure.cloud.redislabs.com:10414");
        System.out.println("Connected to Redis!");

        String connectionString = "mongodb+srv://zhenglinli:i7EHnzmdP9YWhvyi@cluster0.fc4iuts.mongodb.net/?retryWrites=true&w=majority";
        try (MongoClient mongoClient = MongoClients.create(connectionString)) {
            mongoDatabase = mongoClient.getDatabase("coding6");
            System.out.println("Connected to MongoDB!");
        } catch (Exception e) {
            System.out.println("MongoDB access error!");
            e.printStackTrace();
            throw e;
        }
    }

    public User loadUser(String username, String password) {
        try {
            String userKey = "user:" + username;
            if (jedis.exists(userKey)) {
                Map<String, String> userData = jedis.hgetAll(userKey);

                String passwordInRedis = userData.get("password");
                if (passwordInRedis != null && passwordInRedis.equals(password)) {
                    User user = new User();
                    user.setUserID(Integer.parseInt(userData.get("userID")));
                    user.setUsername(userData.get("username"));
                    user.setPassword(userData.get("password"));
                    user.setFullName(userData.get("displayName"));
                    System.out.println("User loaded successfully!");
                    return user;
                }
            }
            return null;
        } catch (JedisException e) {
            System.out.println("Redis access error!");
            e.printStackTrace();
            return null;
        }
    }

    public Product loadProduct(int id) {
        System.out.println("Loading product " + id + " from Redis...");
        Map<String, String> productData = jedis.hgetAll("product:" + id);
        if (productData != null) {
            Product product = new Product();
            product.setProductID(Integer.parseInt(productData.get("id")));
            product.setName(productData.get("name"));
            product.setPrice(Double.parseDouble(productData.get("price")));
            product.setQuantity(Double.parseDouble(productData.get("quantity")));
            return product;
        }
        return null;
    }

    public boolean saveProduct(Product product) {
        try {
            String productKey = "product:" + product.getProductID();
            // In Redis, we don't need to check if the product exists as HSET will create or update fields
            jedis.hset(productKey, "id", "" + product.getProductID());
            jedis.hset(productKey, "name", product.getName());
            jedis.hset(productKey, "price", String.valueOf(product.getPrice()));
            jedis.hset(productKey, "quantity", String.valueOf(product.getQuantity()));
            return true;        // save successfully
        } catch (JedisException e) {
            System.out.println("Database access error!");
            e.printStackTrace();
            return false; // cannot save!
        }
    }

    public PaymentInfo loadPaymentInfo(int userID) {
        try {
            String paymentInfoKey = "paymentInfo:" + userID;
            if (jedis.exists(paymentInfoKey)) {
                Map<String, String> paymentData = jedis.hgetAll(paymentInfoKey);

                PaymentInfo paymentInfo = new PaymentInfo();
                paymentInfo.setUserID(userID); // UserID is known, as it's part of the key
                paymentInfo.setCardNumber(paymentData.get("cardNumber"));
                paymentInfo.setCsv(paymentData.get("csv"));

                return paymentInfo;
            }
            return null;
        } catch (JedisException e) {
            System.out.println("Redis access error!");
            e.printStackTrace();
        }
        return null;
    }

    public boolean savePaymentInfo(PaymentInfo paymentInfo) {
        try {
            String paymentInfoKey = "paymentInfo:" + paymentInfo.getUserID();
            jedis.hset(paymentInfoKey, "cardNumber", paymentInfo.getCardNumber());
            jedis.hset(paymentInfoKey, "csv", paymentInfo.getCsv());
            return true;        // save successfully
        } catch (JedisException e) {
            System.out.println("Redis access error!");
            e.printStackTrace();
            return false; // Cannot save
        }
    }

    public ShipmentInfo loadShipmentInfo(int userID) {
        try {
            String shipmentInfoKey = "shipmentInfo:" + userID;
            if (jedis.exists(shipmentInfoKey)) {
                Map<String, String> shipmentData = jedis.hgetAll(shipmentInfoKey);

                ShipmentInfo shipmentInfo = new ShipmentInfo();
                shipmentInfo.setUserID(userID); // UserID is known, as it's part of the key
                shipmentInfo.setAddress(shipmentData.get("address"));

                return shipmentInfo;
            }
            return null;
        } catch (JedisException e) {
            System.out.println("Redis access error!");
            e.printStackTrace();
        }
        return null;
    }

    public boolean saveShipmentInfo(ShipmentInfo shipmentInfo) {
        try {
            String shipmentInfoKey = "shipmentInfo:" + shipmentInfo.getUserID();

            // In Redis, setting a hash value will create or update the hash
            jedis.hset(shipmentInfoKey, "address", shipmentInfo.getAddress());

            return true; // Save successfully

        } catch (JedisException e) {
            System.out.println("Redis access error!");
            e.printStackTrace();
            return false; // Cannot save
        }
    }

    public List<Receipt> loadReceipt(int userID) {
        MongoDatabase mongoDatabase;
        String connectionString = "mongodb+srv://zhenglinli:i7EHnzmdP9YWhvyi@cluster0.fc4iuts.mongodb.net/?retryWrites=true&w=majority";
        MongoClient mongoClient = MongoClients.create(connectionString);
        mongoDatabase = mongoClient.getDatabase("coding6");
        System.out.println("Connected to MongoDB!");

        try {
            MongoCollection<Document> collection = mongoDatabase.getCollection("Receipts");

            Document query = new Document("UserID", userID);
            FindIterable<Document> receiptDocs = collection.find(query);

            List<Receipt> res = new ArrayList<>();
            for (Document receiptDoc : receiptDocs) {
                Receipt receipt = new Receipt();
                receipt.setOrderID(receiptDoc.getInteger("OrderID"));
                receipt.setUserID(receiptDoc.getInteger("UserID"));
                receipt.setContent(receiptDoc.getString("Content"));

                res.add(receipt);
            }

            return res;
        } catch (Exception e) {
            System.out.println("MongoDB access error!");
            e.printStackTrace();
            return null;
        }
    }

    public boolean saveReceipt(Receipt receipt) {
        MongoDatabase mongoDatabase;
        String connectionString = "mongodb+srv://zhenglinli:i7EHnzmdP9YWhvyi@cluster0.fc4iuts.mongodb.net/?retryWrites=true&w=majority";
        MongoClient mongoClient = MongoClients.create(connectionString);
        mongoDatabase = mongoClient.getDatabase("coding6");
        System.out.println("Connected to MongoDB!");

        MongoCollection<Document> collection = mongoDatabase.getCollection("Receipts");

        Document receiptDoc = new Document("OrderID", receipt.getOrderID()).append("UserID", receipt.getUserID()).append("Content", receipt.getContent());

        try {
            collection.insertOne(receiptDoc); // Insert the receipt document
            return true;
        } catch (Exception e) {
            System.out.println("MongoDB access error!");
            e.printStackTrace();
            return false;
        }
    }

    public Order loadOrder(int id) {
        MongoCollection<Document> collection = mongoDatabase.getCollection("Orders");

        Document query = new Document("OrderID", id);
        Document orderDoc = collection.find(query).first();

        if (orderDoc != null) {
            Order order = new Order();
            order.setOrderID(orderDoc.getInteger("OrderID"));
            order.setBuyerID(orderDoc.getInteger("CustomerID"));
            order.setTotalCost(orderDoc.getDouble("TotalCost"));
            order.setDateTime(orderDoc.getString("OrderDate"));

            // Loading the order lines (embedded documents)
            List<Document> lines = (List<Document>) orderDoc.get("OrderLines");
            if (lines != null) {
                for (Document lineDoc : lines) {
                    OrderLine line = new OrderLine();
                    line.setOrderID(lineDoc.getInteger("OrderID"));
                    line.setProductID(lineDoc.getInteger("ProductID"));
                    line.setQuantity(lineDoc.getDouble("Quantity"));
                    line.setCost(lineDoc.getDouble("Cost"));
                    order.addLine(line);
                }
            }

            return order;
        }

        return null;
    }

    public boolean saveOrder(Order order) {
        MongoDatabase mongoDatabase;
        String connectionString = "mongodb+srv://zhenglinli:i7EHnzmdP9YWhvyi@cluster0.fc4iuts.mongodb.net/?retryWrites=true&w=majority";
        MongoClient mongoClient = MongoClients.create(connectionString);
        mongoDatabase = mongoClient.getDatabase("coding6");
        System.out.println("Connected to MongoDB!");

        MongoCollection<Document> collection = mongoDatabase.getCollection("Orders");

        Document orderDoc = new Document("OrderID", order.getOrderID()).append("CustomerID", order.getBuyerID()).append("TotalCost", order.getTotalCost()).append("OrderDate", order.getDateTime()).append("TotalTax", order.getTotalTax());

        List<Document> lineDocs = new ArrayList<>();
        for (OrderLine line : order.getLines()) {
            Document lineDoc = new Document("OrderID", line.getOrderID()).append("ProductID", line.getProductID()).append("Quantity", line.getQuantity()).append("Cost", line.getCost());
            lineDocs.add(lineDoc);
        }
        orderDoc.append("OrderLines", lineDocs);

        try {
            collection.insertOne(orderDoc); // Insert the order document
            return true;
        } catch (Exception e) {
            System.out.println("MongoDB access error!");
            e.printStackTrace();
            return false;
        }
    }
}
