import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class ProductController implements ActionListener {
    private ProductView productView;

    public ProductController(ProductView productView) {
        this.productView = productView;

        productView.getBtnLoad().addActionListener(this);
        productView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == productView.getBtnLoad())
            loadProduct();
        else if (e.getSource() == productView.getBtnSave())
            saveProduct();
    }

    private void saveProduct() {
        // add data validation
        int productID;
        String productIDString = productView.getTxtProductID().getText();
        if (!isValidProductId(productIDString)) {
            JOptionPane.showMessageDialog(null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }
        productID = Integer.parseInt(productIDString);

        // add data validation
        double productPrice;
        String productPriceString = productView.getTxtProductPrice().getText();
        if (!isValidPrice(productPriceString)) {
            JOptionPane.showMessageDialog(null, "Invalid product price! Please provide a valid product price!");
            return;
        }
        productPrice = Double.parseDouble(productPriceString);

        // add data validation
        double productQuantity;
        String productQuantityString = productView.getTxtProductQuantity().getText().trim();
        System.out.println("productQuantityString = " + productQuantityString);
        if (!isValidQuantity(productQuantityString)) {
            JOptionPane.showMessageDialog(null, "Invalid product quantity! Please provide a valid product quantity!");
            return;
        }
        productQuantity = Integer.parseInt(productQuantityString);

        // add data validation
        String productName = productView.getTxtProductName().getText().trim();
        if (!isValidProductName(productName)) {
            JOptionPane.showMessageDialog(null, "Invalid product name! Please provide a non-empty product name!");
            return;
        }

        // Done all validations! Make an object for this product!

        Product product = new Product();
        product.setProductID(productID);
        product.setSellerID(Application.getInstance().getCurrentUser().getUserID());
        product.setName(productName);
        product.setPrice(productPrice);
        product.setQuantity(productQuantity);

        // Store the product to the database

        Application.getInstance().getDataAdapter().saveProduct(product);
    }

    private void loadProduct() {
        int productID = 0;
        try {
            productID = Integer.parseInt(productView.getTxtProductID().getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid product ID! Please provide a valid product ID!");
            return;
        }

        Product product = Application.getInstance().getDataAdapter().loadProduct(productID);

        if (product == null) {
            JOptionPane.showMessageDialog(null, "This product ID does not exist in the database!");
            return;
        }

        productView.getTxtProductName().setText(product.getName());
        productView.getTxtProductPrice().setText(String.valueOf(product.getPrice()));
        productView.getTxtProductQuantity().setText(String.valueOf(product.getQuantity()));
    }

    // add data validation
    private boolean isValidProductId(String productId) {
        int productID;
        try {
            productID = Integer.parseInt(productId);
        } catch (NumberFormatException e) {
            return false;
        }
        return productID > 0;
    }

    // add data validation
    private boolean isValidPrice(String productPriceString) {
        double productPrice;
        try {
            productPrice = Double.parseDouble(productPriceString);
        } catch (NumberFormatException e) {
            return false;
        }
        return productPrice > 0;
    }


    // add data validation
    private boolean isValidQuantity(String quantityString) {
        int quantity;
        try {
            quantity = Integer.parseInt(quantityString);
        } catch (NumberFormatException e) {
            return false;
        }
        return quantity > 0;
    }


    // add data validation
    private boolean isValidProductName(String productName) {
        return productName.trim().length() > 0 && productName.trim().length() < Integer.MAX_VALUE;
    }
}


class ProductView extends JFrame {
    private JTextField txtProductID = new JTextField(10);
    private JTextField txtProductName = new JTextField(30);
    private JTextField txtProductPrice = new JTextField(10);
    private JTextField txtProductQuantity = new JTextField(10);

    private JButton btnLoad = new JButton("Load main.java.Product");
    private JButton btnSave = new JButton("Save main.java.Product");

    public ProductView() {
        this.setTitle("Manage Products");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 200);

        JPanel panelButton = new JPanel();
        panelButton.add(btnLoad);
        panelButton.add(btnSave);
        this.getContentPane().add(panelButton);

        JPanel panelProductID = new JPanel();
        panelProductID.add(new JLabel("main.java.Product ID: "));
        panelProductID.add(txtProductID);
        txtProductID.setHorizontalAlignment(JTextField.RIGHT);
        this.getContentPane().add(panelProductID);

        JPanel panelProductName = new JPanel();
        panelProductName.add(new JLabel("main.java.Product Name: "));
        panelProductName.add(txtProductName);
        this.getContentPane().add(panelProductName);

        JPanel panelProductInfo = new JPanel();
        panelProductInfo.add(new JLabel("Price: "));
        panelProductInfo.add(txtProductPrice);
        txtProductPrice.setHorizontalAlignment(JTextField.RIGHT);

        panelProductInfo.add(new JLabel("Quantity: "));
        panelProductInfo.add(txtProductQuantity);
        txtProductQuantity.setHorizontalAlignment(JTextField.RIGHT);

        this.getContentPane().add(panelProductInfo);

    }

    public JButton getBtnLoad() {
        return btnLoad;
    }

    public JButton getBtnSave() {
        return btnSave;
    }

    public JTextField getTxtProductID() {
        return txtProductID;
    }

    public JTextField getTxtProductName() {
        return txtProductName;
    }

    public JTextField getTxtProductPrice() {
        return txtProductPrice;
    }

    public JTextField getTxtProductQuantity() {
        return txtProductQuantity;
    }
}
