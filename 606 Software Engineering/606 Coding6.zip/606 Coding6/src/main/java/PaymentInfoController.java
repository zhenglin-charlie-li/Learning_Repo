import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class PaymentInfoController implements ActionListener {
    private PaymentInfoView paymentInfoView;

    public PaymentInfoController(PaymentInfoView paymentInfoView) {
        this.paymentInfoView = paymentInfoView;

        paymentInfoView.getBtnLoad().addActionListener(this);
        paymentInfoView.getBtnSave().addActionListener(this);
    }


    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == paymentInfoView.getBtnLoad())
            loadPaymentInfo();
        else if (e.getSource() == paymentInfoView.getBtnSave())
            savePaymentInfo();
    }

    private void savePaymentInfo() {
        // add data validation
        String paymentInfoCardNumber = paymentInfoView.getTxtPaymentInfoCardNumber().getText().trim();
        if (!isValidPaymentInfoCardNumber(paymentInfoCardNumber)) {
            JOptionPane.showMessageDialog(null, "Invalid paymentInfo card number! Please provide a valid paymentInfo card number!");
            return;
        }
        // add data validation
        String paymentInfoCsv = paymentInfoView.getTxtPaymentInfoCsv().getText().trim();
        if (!isValidPaymentInfoCsv(paymentInfoCsv)) {
            JOptionPane.showMessageDialog(null, "Invalid paymentInfo card csv! Please provide a valid paymentInfo card csv!");
            return;
        }

        // Done all validations! Make an object for this paymentInfo!

        PaymentInfo paymentInfo = new PaymentInfo();
        paymentInfo.setUserID(Application.getInstance().getCurrentUser().getUserID());
        paymentInfo.setCardNumber(paymentInfoCardNumber);
        paymentInfo.setCsv(paymentInfoCsv);

        // Store the paymentInfo to the database

        Application.getInstance().getDataAdapter().savePaymentInfo(paymentInfo);
    }

    private void loadPaymentInfo() {
        int userID = Application.getInstance().getCurrentUser().getUserID();

        PaymentInfo paymentInfo = Application.getInstance().getDataAdapter().loadPaymentInfo(userID);

        if (paymentInfo == null) {
            JOptionPane.showMessageDialog(null, "This paymentInfo ID does not exist in the database!");
            return;
        }

        paymentInfoView.getTxtPaymentInfoCardNumber().setText(paymentInfo.getCardNumber());
        paymentInfoView.getTxtPaymentInfoCsv().setText(paymentInfo.getCsv());
    }


    // add data validation
    private boolean isValidPaymentInfoCardNumber(String paymentInfoCardNumber) {
        for (char c : paymentInfoCardNumber.toCharArray()) {
            if (c > '9' || c < '0') {
                return false;
            }
        }
        return !paymentInfoCardNumber.isBlank()
                && paymentInfoCardNumber.length() == 20;
    }


    // add data validation
    private boolean isValidPaymentInfoCsv(String paymentInfoCsv) {
        for (char c : paymentInfoCsv.toCharArray()) {
            if (c > '9' || c < '0') {
                return false;
            }
        }
        return !paymentInfoCsv.isBlank() && paymentInfoCsv.length() == 3;
    }
}


class PaymentInfoView extends JFrame {
    private JTextField txtPaymentInfoCardNumber = new JTextField(30);
    private JTextField txtPaymentInfoCsv = new JTextField(30);

    private JButton btnLoad = new JButton("Load main.java.PaymentInfo");
    private JButton btnSave = new JButton("Save main.java.PaymentInfo");

    public PaymentInfoView() {
        this.setTitle("Manage main.java.PaymentInfo");
        this.setLayout(new BoxLayout(this.getContentPane(), BoxLayout.PAGE_AXIS));
        this.setSize(500, 200);

        JPanel panelButton = new JPanel();
        panelButton.add(btnLoad);
        panelButton.add(btnSave);
        this.getContentPane().add(panelButton);

        JPanel panelPaymentInfoCardNumber = new JPanel();
        panelPaymentInfoCardNumber.add(new JLabel("Card Number: "));
        panelPaymentInfoCardNumber.add(txtPaymentInfoCardNumber);
        this.getContentPane().add(panelPaymentInfoCardNumber);

        JPanel panelPaymentInfoCsv = new JPanel();
        panelPaymentInfoCsv.add(new JLabel("CSV: "));
        panelPaymentInfoCsv.add(txtPaymentInfoCsv);
        this.getContentPane().add(panelPaymentInfoCsv);

    }

    public JButton getBtnLoad() {
        return btnLoad;
    }

    public JButton getBtnSave() {
        return btnSave;
    }

    public JTextField getTxtPaymentInfoCardNumber() {
        return txtPaymentInfoCardNumber;
    }

    public JTextField getTxtPaymentInfoCsv() {
        return txtPaymentInfoCsv;
    }
}
