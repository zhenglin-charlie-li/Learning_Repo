# readme file on coding2

## link to youtube: https://youtu.be/gpl1ICDtmD0

## Documentation for DataAdapter Class

![img.png](img.png)

### Overview

The DataAdapter class serves as an interface between the application and two distinct data storage systems: MongoDB and
Redis. This class encapsulates the logic for interacting with these databases, providing methods to load and save
various data entities like users, products, payment information, shipment details, receipts, and orders.

### Class Structure

1. Private Members:
    2. Jedis jedis: A client connection to a Redis server.
    3. MongoDatabase mongoDatabase: A connection to a MongoDB database.
1. Constructor:
    2. Initializes the Redis and MongoDB clients with specific connection details.
1. Methods
    2. User Authentication (loadUser): Checks if a user exists in Redis and validates their credentials.
    3. Product Management (loadProduct, saveProduct):Load product details from Redis using a product ID. Save or update
       product details in Redis.
    4. Payment Information Handling (loadPaymentInfo, savePaymentInfo):Load and save user's payment information in
       Redis.
    5. Shipment Information Management (loadShipmentInfo, saveShipmentInfo):Load and save user's shipment information in
       Redis.
    6. Receipt Handling (loadReceipt, saveReceipt):Retrieves a list of receipts from MongoDB and saves new receipts.
    7. Order Processing (loadOrder, saveOrder):Load and save order details in MongoDB, including embedded order lines.

### Usage Notes

The class connects to Redis and MongoDB using credentials provided in the constructor. These should be replaced with
actual credentials for a production environment.
Exception handling is implemented for both Redis and MongoDB operations to ensure robustness.
The class methods demonstrate the use of basic CRUD operations in both Redis and MongoDB.
The MongoDB connection is established and closed within the constructor, which might not be ideal for real-world
applications. It is generally better to maintain a persistent connection or use a connection pool.
Dependencies
MongoDB Java Driver: For MongoDB operations.
Jedis: For Redis operations.

### Security Notes

The class contains hardcoded sensitive information (database credentials), which is not recommended for production code.
These should be secured and loaded from a configuration file or environment variables.
Proper error handling and logging should be implemented for a production-grade application.